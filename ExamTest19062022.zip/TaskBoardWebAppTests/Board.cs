﻿namespace ExamWebAppTests
{
    public class Board
    {
        public string Name
        {
            get;
            private set;
        }

        public Board(string name)
        {
            this.Name = name;
        }
    }
}
